Simple lightweight input recording software capable of recording and playing back mouse movement, mouse inputs and keyboard inputs.

Schedules the inputs instead of playing them with delays to get around the issue of slowed down playbacks that some other macro recording softwares face.

to use simply get the jar file from the most recent release and run it. If you don't have Java installed go to https://www.java.com/ and get the latest Java version.

This is my first real Java project so do mind that my way of doing things in the source code could be sub-optimal at times.

@2024. This work is openly licensed via https://creativecommons.org/licenses/by-sa/4.0/
